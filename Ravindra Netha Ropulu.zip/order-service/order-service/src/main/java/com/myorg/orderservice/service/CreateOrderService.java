package com.myorg.orderservice.service;

import com.myorg.orderservice.accessor.OrderItemAccessor;
import com.myorg.orderservice.com.myorg.orderservice.exception.OrderServiceException;
import com.myorg.orderservice.dao.OrderEntity;
import com.myorg.orderservice.dao.OrderRepository;
import com.myorg.orderservice.domain.OrderItem;
import com.myorg.orderservice.domain.OrderItemDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class CreateOrderService {

    @Autowired
    private OrderItemAccessor orderItemAccessor;

    @Autowired
    private OrderRepository orderRepository;

    public boolean createOrder(OrderItem orderItem) {
        OrderItemDTO orderItemDTO = orderItemAccessor.getOrderItem(orderItem.getProductCode());
        if (orderItemDTO.getQuantity() > orderItem.getOrderQuantity()) {
            OrderEntity orderEntity = new OrderEntity();
            orderEntity.setCustomerName(orderItem.getCustomerName());
            orderEntity.setShipingAddress(orderItem.getAddress());
            orderEntity.setOrderId(UUID.randomUUID().toString());
            orderRepository.save(orderEntity);
        } else {
            throw new OrderServiceException("Product is not available");
        }
        return false;
    }

    public Page<OrderEntity> getOrders(Pageable pageable) {
        return orderRepository.findAll(pageable);
    }

}
