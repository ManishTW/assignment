package com.myorg.orderservice.accessor;

import com.myorg.orderservice.domain.OrderItemDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient("orderItemAccessor")
public interface OrderItemAccessor {

    @RequestMapping(path = "/products/{productCode}", method = RequestMethod.GET)
    OrderItemDTO getOrderItem(@PathVariable(value = "productCode") String productCode);

}
