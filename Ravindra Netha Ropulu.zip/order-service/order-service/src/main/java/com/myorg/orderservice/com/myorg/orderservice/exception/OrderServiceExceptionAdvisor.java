package com.myorg.orderservice.com.myorg.orderservice.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class OrderServiceExceptionAdvisor {




}
