package com.myorg.orderservice.domain;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class OrderItem {

    @NotBlank(message = "product name can not be blank")
    private String productName;

    @NotBlank(message = "product code can not be blank")
    private String productCode;

    @NotBlank(message = "customer name can not be blank")
    private String customerName;
    @Min(value = 1,message = "order quantity should be at least 1")
    private Long orderQuantity;
    @NotBlank(message = "address name can not be blank")
    private String address;

    public String getAddress() {
        return address;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Long getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(Long orderQuantity) {
        this.orderQuantity = orderQuantity;
    }
}
