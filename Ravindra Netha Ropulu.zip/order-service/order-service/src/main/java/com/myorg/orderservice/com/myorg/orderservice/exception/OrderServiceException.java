package com.myorg.orderservice.com.myorg.orderservice.exception;

public class OrderServiceException extends RuntimeException{

    public OrderServiceException(String message) {
        super(message);
    }
}
