package com.myorg.orderservice.dao;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Table(name = "myorg_order")
public class OrderEntity {

    @Id
    private String orderId;
    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "order_creation_timestamp")
    private Date orderCreationTimestamp;
    @Column(name = "shpping_address")
    private String shipingAddress;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Date getOrderCreationTimestamp() {
        return orderCreationTimestamp;
    }

    public void setOrderCreationTimestamp(Date orderCreationTimestamp) {
        this.orderCreationTimestamp = orderCreationTimestamp;
    }

    public String getShipingAddress() {
        return shipingAddress;
    }

    public void setShipingAddress(String shipingAddress) {
        this.shipingAddress = shipingAddress;
    }
}
