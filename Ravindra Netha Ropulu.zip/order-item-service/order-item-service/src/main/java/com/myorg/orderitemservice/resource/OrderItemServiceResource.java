package com.myorg.orderitemservice.resource;

import com.myorg.orderitemservice.dao.OrderItemEntity;
import com.myorg.orderitemservice.domain.CreateOrderItem;
import com.myorg.orderitemservice.domain.OrderItem;
import com.myorg.orderitemservice.domain.OrderItemDTO;
import com.myorg.orderitemservice.service.OrderItemService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class OrderItemServiceResource {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrderItemServiceResource.class);

    @Autowired
    private OrderItemService orderItemService;

    @PostMapping("products")
    public ResponseEntity<OrderItemEntity> placeProduct(@Valid @RequestBody CreateOrderItem createOrderItem) {

        LOGGER.info("Creating products");

        return ResponseEntity.ok(orderItemService.createProducts(createOrderItem));
    }

    @PatchMapping("products/{productCode}")
    public ResponseEntity updateProductQuanity(@PathVariable("productCode") String productCode, @RequestBody OrderItem orderItem) {

        LOGGER.info("Updating products");

        orderItemService.updateProducts(orderItem, productCode);

        return ResponseEntity.noContent().build();
    }

    @GetMapping("products/{productCode}")
    public ResponseEntity<OrderItemDTO> getProducts(@PathVariable(value = "productCode") String productCode, Pageable pageable) {

        return ResponseEntity.ok(orderItemService.getOrderItemEntity(productCode));
    }

    @GetMapping("products")
    public ResponseEntity<Page<OrderItemEntity>> getAllProducts(Pageable pageable) {

        return ResponseEntity.ok(orderItemService.getOrderItemEntity(pageable));
    }

}
