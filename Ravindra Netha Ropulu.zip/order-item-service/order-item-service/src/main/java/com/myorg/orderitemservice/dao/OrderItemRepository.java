package com.myorg.orderitemservice.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface OrderItemRepository extends PagingAndSortingRepository<OrderItemEntity, String> {


    OrderItemEntity findByProductCode(String productCode);

}
