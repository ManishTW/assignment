package com.myorg.orderitemservice.service;

import com.myorg.orderitemservice.com.myorg.orderitemservice.exception.OrderItemServiceException;
import com.myorg.orderitemservice.dao.OrderItemEntity;
import com.myorg.orderitemservice.dao.OrderItemRepository;
import com.myorg.orderitemservice.domain.CreateOrderItem;
import com.myorg.orderitemservice.domain.OrderItem;
import com.myorg.orderitemservice.domain.OrderItemDTO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Optional;
import java.util.UUID;

@Service
public class OrderItemService {

    @Autowired
    private OrderItemRepository orderItemRepository;

    public OrderItemEntity createProducts(CreateOrderItem createOrderItem) {
        return orderItemRepository.save(buildOrderItemEntity(createOrderItem));
    }

    public void updateProducts(OrderItem orderItem, String productCode) {

        OrderItemEntity product = orderItemRepository.findById(productCode).orElseThrow(() -> new OrderItemServiceException("Product Not found"));

        product.setQuantity(orderItem.getQuantity() != null ? orderItem.getQuantity() : product.getQuantity());
        product.setProductName(orderItem.getProductName() != null ? orderItem.getProductName() : product.getProductName());
        product.setProductPrice(orderItem.getProductPrice() != null ? orderItem.getProductPrice() : product.getProductPrice());

    }


    private OrderItemEntity buildOrderItemEntity(CreateOrderItem createOrderItem) {

        OrderItemEntity orderItemEntity = new OrderItemEntity();
        orderItemEntity.setProductCode(UUID.randomUUID().toString());
        orderItemEntity.setProductName(createOrderItem.getProductName());
        orderItemEntity.setQuantity(orderItemEntity.getQuantity());
        orderItemEntity.setProductPrice(orderItemEntity.getProductPrice());
        return orderItemEntity;
    }

    public OrderItemDTO getOrderItemEntity(String productCode) {
        OrderItemDTO orderItemDTO = new OrderItemDTO();
        BeanUtils.copyProperties(orderItemRepository.findByProductCode(productCode), orderItemDTO);
        return orderItemDTO;
    }

    public Page<OrderItemEntity> getOrderItemEntity(Pageable pageable) {

        return orderItemRepository.findAll(pageable);

    }

}
