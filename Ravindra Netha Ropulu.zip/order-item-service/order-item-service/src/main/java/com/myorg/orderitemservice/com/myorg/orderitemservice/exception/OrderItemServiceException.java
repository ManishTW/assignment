package com.myorg.orderitemservice.com.myorg.orderitemservice.exception;

public class OrderItemServiceException extends RuntimeException{


    public OrderItemServiceException() {
    }

    public OrderItemServiceException(String message) {
        super(message);
    }
}
