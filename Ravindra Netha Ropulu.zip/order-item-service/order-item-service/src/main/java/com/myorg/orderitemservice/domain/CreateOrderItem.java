package com.myorg.orderitemservice.domain;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class CreateOrderItem {
    @NotBlank(message = "product name can not be blank")
    private String productName;
    @Min(value = 1, message = "product quantity shoud be at least one")
    private Long quantity;
    @Min(value = 1, message = "product quantity shoud be at least one")
    private Long productPrice;

    public Long getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Long productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getQuantity() {
        return quantity;
    }

    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }
}
