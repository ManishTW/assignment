package com.myorg.orderitemservice.com.myorg.orderitemservice.exception;

public class ExceptionResponse {



}
