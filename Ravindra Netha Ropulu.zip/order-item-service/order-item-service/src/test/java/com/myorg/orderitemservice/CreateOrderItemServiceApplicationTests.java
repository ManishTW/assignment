package com.myorg.orderitemservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreateOrderItemServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
