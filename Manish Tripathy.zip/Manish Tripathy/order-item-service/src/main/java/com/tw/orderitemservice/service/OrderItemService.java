package com.tw.orderitemservice.service;

import com.tw.orderitemservice.model.OrderItem;
import com.tw.orderitemservice.repository.OrderItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderItemService {

    private final OrderItemRepository orderItemRepository;

    public List<OrderItem> findItemsForOrder(int orderId) {
        return orderItemRepository.findByOrderId(orderId);
    }

    public void saveItems(int orderId, List<OrderItem> items) {
        items.forEach(item -> item.setOrderId(orderId));
        orderItemRepository.saveAll(items);
    }
}
