package com.tw.orderitemservice.repository;

import com.tw.orderitemservice.model.OrderItem;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface OrderItemRepository extends CrudRepository<OrderItem, Integer> {
  List<OrderItem> findByOrderId(int orderId);
}
