package com.tw.orderitemservice.controller;

import com.tw.orderitemservice.model.OrderItem;
import com.tw.orderitemservice.service.OrderItemService;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/order-items/{orderId}")
public class OrderItemController {
    private final OrderItemService orderItemService;

    @GetMapping
    public ResponseEntity<OrderItemsResponse> getOrderItems(@PathVariable int orderId) {
        List<OrderItem> items = orderItemService.findItemsForOrder(orderId);
        return ResponseEntity.ok(new OrderItemsResponse(items));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void addOrderItems(@PathVariable int orderId, @RequestBody List<OrderItem> items) {
        orderItemService.saveItems(orderId, items);
    }
}

@Value
class OrderItemsResponse {
    List<OrderItem> items;
}
