package com.tw.orderitemservice;

import com.tw.orderitemservice.model.OrderItem;
import com.tw.orderitemservice.repository.OrderItemRepository;
import com.tw.orderitemservice.service.OrderItemService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoSettings;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@MockitoSettings
class OrderItemServiceTest {

    @Mock
    OrderItemRepository orderItemRepository;

    private OrderItemService orderItemService;

    @BeforeEach
    void setUp() {
        orderItemService = new OrderItemService(orderItemRepository);
    }

    @Test
    void shouldFetchAllOrderItemsByOrderId() {
        // Given
        int orderId = 10;
        OrderItem item1 = OrderItem.builder().id(1).orderId(orderId).productName("name1").productCode("code1").quantity(5).build();
        OrderItem item2 = OrderItem.builder().id(2).orderId(orderId).productName("name2").productCode("code2").quantity(2).build();
        List<OrderItem> items = List.of(item1, item2);
        when(orderItemRepository.findByOrderId(orderId)).thenReturn(items);

        // When
        List<OrderItem> orderItems = orderItemService.findItemsForOrder(orderId);

        // Then
        assertThat(orderItems).isEqualTo(items);
    }

    @Test
    void shouldSaveOrderItemsForGivenOrder() {
        // Given
        int orderId = 10;
        OrderItem item1 = OrderItem.builder().id(1).orderId(orderId).productName("name1").productCode("code1").quantity(5).build();
        OrderItem item2 = OrderItem.builder().id(2).orderId(orderId).productName("name2").productCode("code2").quantity(2).build();
        List<OrderItem> items = List.of(item1, item2);

        // When
        orderItemService.saveItems(orderId, items);

        // Then
        verify(orderItemRepository).saveAll(items);
    }
}
