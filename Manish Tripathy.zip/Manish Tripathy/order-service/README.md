# How to run the app

- Prerequisites:
    - Make sure to start order-item-service prior to starting this
    - Java 11 (`jenv` can be used to set local java version in Mac)
    
Run the below commands from inside the project
```bash
./gradlew bootRun
```

### Available endpoints
1. POST http://localhost:8082/orders/
```json
{
	"customerName": "Manish Tripathy",
	"shippingAddress": "Thoughtworks",
	"items": [
        {
            "productName": "Product 1",
            "productCode": "S01",
            "quantity": 10
        },
        {
            "productName": "Product 2",
            "productCode": "D01",
            "quantity": 20
        }
    ],
    "total": 500
}
```
2. GET http://localhost:8082/orders/1
