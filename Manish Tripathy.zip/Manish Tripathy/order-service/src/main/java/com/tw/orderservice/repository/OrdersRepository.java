package com.tw.orderservice.repository;

import com.tw.orderservice.model.Order;
import org.springframework.data.repository.CrudRepository;

public interface OrdersRepository extends CrudRepository<Order, Integer> {
  Order findById(int id);
}
