package com.tw.orderservice.exception;

import lombok.RequiredArgsConstructor;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
    @ExceptionHandler(OrderNotFoundException.class)
    public final ResponseEntity<ApiError> handOrderNotFoundException(Exception exception) {
        return new ResponseEntity<>(new ApiError(exception), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public final ResponseEntity<ApiError> handleValidations(MethodArgumentNotValidException exception) {
        String errorMessage = exception.getBindingResult().getFieldError().getDefaultMessage();
        return new ResponseEntity<>(new ApiError(errorMessage), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<ApiError> handleInternalError(Exception exception) {
        log.error("Something went wrong", exception);
        return new ResponseEntity<>(new ApiError("Something went wrong"), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

@Value
@RequiredArgsConstructor
class ApiError {
    String error;

   ApiError(Exception exception) {
       this.error = exception.getMessage();
   }
}