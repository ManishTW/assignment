package com.tw.orderservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.List;

@Builder(toBuilder = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @NotNull(message = "Customer name is required")
    @NotEmpty(message = "Customer name cannot be empty")
    private String customerName;

    @Builder.Default
    @Column(name="order_date")
    private LocalDate date = LocalDate.now();

    @NotNull(message = "Shipping address is required")
    private String shippingAddress;

    @NotNull(message = "Order total is required")
    private Double total;

    @Transient
    @Valid
    private List<OrderItem> items;

    public String getTotal() {
        return NumberFormat.getCurrencyInstance().format(total);
    }
}
