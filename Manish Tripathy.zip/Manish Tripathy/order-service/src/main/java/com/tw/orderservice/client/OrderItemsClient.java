package com.tw.orderservice.client;

import com.tw.orderservice.model.OrderItem;
import com.tw.orderservice.model.OrderItemsResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(value = "orderItems", url = "http://localhost:8081/order-items")
public interface OrderItemsClient {
    @GetMapping(value = "/{orderId}")
    OrderItemsResponse getItems(@PathVariable("orderId") int orderId);

    @PostMapping(value = "/{orderId}")
    void addItems(@PathVariable("orderId") int orderId, @RequestBody List<OrderItem> items);
}
