package com.tw.orderservice.controller;

import com.tw.orderservice.exception.OrderNotFoundException;
import com.tw.orderservice.model.Order;
import com.tw.orderservice.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.net.URI;

@RequiredArgsConstructor
@RestController
@RequestMapping("/orders")
public class OrderController {
    private final OrderService orderService;

    @GetMapping("/{orderId}")
    public ResponseEntity<Order> fetchOrder(@PathVariable int orderId) {
        return orderService
                .findOrder(orderId)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new OrderNotFoundException(orderId));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<OrderResponse> createOrder(@RequestBody @Valid Order order) {
        int orderId = orderService.createOrder(order);
        return ResponseEntity.created(URI.create("/orders/"+orderId))
                .body(new OrderResponse(orderId));
    }
}

@Value
class OrderResponse {
    int id;
}
