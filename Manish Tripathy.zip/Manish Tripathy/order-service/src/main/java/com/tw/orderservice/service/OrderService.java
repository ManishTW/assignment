package com.tw.orderservice.service;

import com.tw.orderservice.client.OrderItemsClient;
import com.tw.orderservice.repository.OrdersRepository;
import com.tw.orderservice.model.Order;
import com.tw.orderservice.model.OrderItem;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrdersRepository orderRepository;
    private final OrderItemsClient orderItemsClient;

    public Optional<Order> findOrder(int orderId) {
        return Optional.ofNullable(orderRepository.findById(orderId))
                .map(order -> {
                    List<OrderItem> items = orderItemsClient.getItems(orderId).getItems();
                    return order.toBuilder().items(items).build();
                });
    }

    public int createOrder(Order order) {
        Order savedOrder = orderRepository.save(order);
        orderItemsClient.addItems(order.getId(), order.getItems());

        return savedOrder.getId();
    }
}
