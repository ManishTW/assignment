package com.tw.orderservice.model;

import lombok.Value;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Value
public class OrderItem {
    @NotNull(message = "Product name is required")
    @NotEmpty(message = "Product name cannot be empty")
    String productName;

    @NotNull(message = "Product code is required")
    @NotEmpty(message = "Product code cannot be empty")
    String productCode;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Minimum quantity is 1")
    Integer quantity;
}
