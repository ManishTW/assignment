package com.tw.orderservice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Getter
@ToString
@NoArgsConstructor
public class OrderItemsResponse {
    public List<OrderItem> items;
}
