package com.oms.item.service;

import java.util.Collection;
import java.util.List;

import com.oms.item.model.OrderItem;

public interface OrderItemService {

    List<OrderItem> save(List<OrderItem> orderItem);

    Collection<OrderItem> findItems(List<Long> ids);

    List<OrderItem> findItemsByOrderId(Long orderId);

}
