package com.oms.item.service;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oms.item.model.OrderItem;
import com.oms.item.repository.OrderItemRepository;

@Service
public class OrderItemImpl implements OrderItemService {

    private OrderItemRepository orderItemRepository;

    @Autowired
    public OrderItemImpl(OrderItemRepository orderItemRepository) {
        super();
        this.orderItemRepository = orderItemRepository;
    }

    @Override
    public Collection<OrderItem> findItems(List<Long> ids) {
        return orderItemRepository.findAllById(ids);
    }

    @Override
    public List<OrderItem> save(List<OrderItem> orderItem) {
        return orderItemRepository.saveAll(orderItem);
    }

    @Override
    public List<OrderItem> findItemsByOrderId(Long orderId) {
        return orderItemRepository.findByOrderId(orderId);
    }

}
