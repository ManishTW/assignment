package com.oms.item;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderItemApplication.class, args);
	}

}
