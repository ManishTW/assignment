package com.oms.order.model;

public class OrderItem {

    private Long id;
    private Long orderId;
    private String productCode;
    private String productName;
    private Integer quantity;
    private Integer price;

    public OrderItem() {
        super();
    }

    public OrderItem(Long id, Long orderId, String productCode, String productName, Integer quantity, Integer price) {
        super();
        this.id = id;
        this.orderId = orderId;
        this.productCode = productCode;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    public Long getId() {
        return id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getProductName() {
        return productName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public Integer getPrice() {
        return price;
    }

    public static OrderItem build(OrderItemDto orderItemDto, Long orderId) {
        return new OrderItem(null, orderId, orderItemDto.getProductCode(), orderItemDto.getProductName(),
                orderItemDto.getQuantity(), orderItemDto.getPrice());
    }
}
