package com.oms.order.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String customerName;
    private LocalDate orderDate;
    private String shippingAddress;
    private Double total;
    
    public Order() {
        super();
    }

    public Order(Long id, String customerName, LocalDate orderDate, String shippingAddress, Double total) {
        super();
        this.id = id;
        this.customerName = customerName;
        this.orderDate = orderDate;
        this.shippingAddress = shippingAddress;
        this.total = total;
    }

    public Long getId() {
        return id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public Double getTotal() {
        return total;
    }

    public static Order build(OrderDto orderDto) {
        return new Order(null, orderDto.getCustomerName(), orderDto.getOrderDate(), orderDto.getShippingAddress(),
                orderDto.getItems().stream().mapToDouble(item -> item.getPrice()).sum());
    }
}
