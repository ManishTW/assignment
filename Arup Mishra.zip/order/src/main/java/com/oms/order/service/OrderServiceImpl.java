package com.oms.order.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oms.exception.OrderNotFoundException;
import com.oms.order.model.Order;
import com.oms.order.model.OrderDto;
import com.oms.order.model.OrderItem;
import com.oms.order.model.OrderItemDto;
import com.oms.order.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

    OrderRepository orderRepository;

    ItemClient itemClient;

    @Autowired
    public OrderServiceImpl(OrderRepository orderRepository, ItemClient itemClient) {
        super();
        this.orderRepository = orderRepository;
        this.itemClient = itemClient;
    }

    @Override
    @Transactional
    public OrderDto save(OrderDto orderDto) {
        Order order = orderRepository.save(Order.build(orderDto));
        List<OrderItem> items = saveOrderItem(orderDto.getItems(), order.getId());
        return buildOrderResponse(order, items);
    }

    @Override
    public List<OrderDto> save(List<OrderDto> orderDto) {
        return orderDto.stream().map(order -> save(order)).collect(Collectors.toList());
    }

    @Override
    public OrderDto findOrder(Long orderId) {
        Order order = orderRepository.findById(orderId).orElse(null);
        if (null == order) {
            throw new OrderNotFoundException("No order present with order id - " + orderId);
        }
        return buildOrderResponse(order, getOrderItems(orderId));
    }

    private List<OrderItem> saveOrderItem(List<OrderItemDto> items, Long orderId) {
        List<OrderItem> orderItems = items.stream().map(item -> OrderItem.build(item, orderId))
                .collect(Collectors.toList());
        return itemClient.saveItems(orderItems);
    }

    private List<OrderItem> getOrderItems(Long orderId) {
        return itemClient.getItems(orderId);
    }

    private OrderDto buildOrderResponse(Order order, List<OrderItem> orderItems) {
        return new OrderDto(order.getId(), order.getCustomerName(), order.getOrderDate(), order.getShippingAddress(),
                orderItems.stream().map((item) -> {
                    return new OrderItemDto(item.getProductCode(), item.getProductName(), item.getQuantity(),
                            item.getPrice());
                }).collect(Collectors.toList()), order.getTotal());
    }

}
