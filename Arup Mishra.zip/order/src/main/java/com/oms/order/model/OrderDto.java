package com.oms.order.model;

import java.time.LocalDate;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

public class OrderDto {

    private Long id;
    @NotBlank(message = "Customer Name is mandatory")
    @NotEmpty(message = "Customer Name cannot be empty")
    private String customerName;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate orderDate;
    @NotBlank(message = "Shipping Address is mandatory")
    @NotEmpty(message = "Shipping address cannot be empty")
    private String shippingAddress;
    @NotEmpty(message = "Items are mandatory")
    private List<OrderItemDto> items;
    private Double total;

    public OrderDto() {
        super();
    }

    public OrderDto(Long id, String customerName, LocalDate orderDate, String shippingAddress, List<OrderItemDto> items,
            Double total) {
        super();
        this.id = id;
        this.customerName = customerName;
        this.orderDate = LocalDate.now();
        this.shippingAddress = shippingAddress;
        this.items = items;
        this.total = total;
    }

    public Long getId() {
        return id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public List<OrderItemDto> getItems() {
        return items;
    }

    public Double getTotal() {
        return total;
    }

}
