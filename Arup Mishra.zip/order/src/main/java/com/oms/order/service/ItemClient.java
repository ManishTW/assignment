package com.oms.order.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.oms.order.model.OrderItem;

@Service
@FeignClient(name = "ItemService", url = "http://localhost:7070")
public interface ItemClient {

	@GetMapping("/api/item")
	public List<OrderItem> getItems(@RequestParam Long orderId);
	
	@PostMapping("/api/item")
	public List<OrderItem> saveItems(@RequestBody List<OrderItem> items);
	

}
