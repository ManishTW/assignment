package com.oms.order.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class OrderItemDto {

    @NotBlank(message = "Product Code is mandatory")
    private String productCode;
    @NotBlank(message = "Product Name is mandatory")
    private String productName;
    @NotNull(message = "Quantity cannot be null")
    private Integer quantity;
    @NotNull(message = "Price cannot be null")
    private Integer price;

    public OrderItemDto() {
        super();
    }

    public OrderItemDto(String productCode, String productName, Integer quantity, Integer price) {
        super();
        this.productCode = productCode;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getProductName() {
        return productName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public Integer getPrice() {
        return price;
    }

    public static OrderItemDtoBuilder builder() {
        return new OrderItemDtoBuilder();
    }

    public static class OrderItemDtoBuilder {
        private String productCode;
        private String productName;
        private Integer quantity;
        private Integer price;

        public OrderItemDtoBuilder withData(String productCode, String productName, Integer quantity, Integer price) {
            this.productCode = productCode;
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
            return this;
        }

        public OrderItemDto build() {
            return new OrderItemDto(this.productCode, this.productName, this.quantity, this.price);
        }
    }

}
