package com.oms.order.service;

import java.util.List;

import com.oms.order.model.OrderDto;

public interface OrderService {
	
	OrderDto save(OrderDto orderDto);
	
	List<OrderDto> save(List<OrderDto> orderDto);

	OrderDto findOrder(Long orderId);

}
