package com.oms.exception;

public class OrderNotFoundException extends RuntimeException {
    /**
     * 
     */
    private static final long serialVersionUID = 6447771098260635002L;

    public OrderNotFoundException(String msg) {
        super(msg);
    }
}
